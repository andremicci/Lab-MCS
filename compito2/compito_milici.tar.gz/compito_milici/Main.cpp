
#include <cmath>
#include <fstream>
#include <vector>
#include <TLegend.h>
#include <TGraph.h>
#include <TF1.h>
#include <TCanvas.h>
#include <TGraph2D.h>
#include <TH2D.h>
#include <TApplication.h>
#include <TStyle.h>
#include <string>
#include <TAttLine.h>
#include <functional>
#include <TLine.h>
#include <iostream>
#include "OdeSolver.h"
#include "Vector.h"
#include "MatPoint.h"

//compito 2 Andrea Milici
//implementazione verlet velocity e confronto con runge kutta 2


using namespace std;

Vector fInternal(unsigned int i, unsigned int j, double t, vector<MatPoint> p)
{

  if (i == j)
  {
    return Vector();
  }
  else
  {
    Vector f;
    f = p[j].GravField(p[i].R());
    return f * p[i].Mass();
  }
}

Vector fExternal(unsigned int i, double t, vector<MatPoint> p)

{

  return Vector();
}

int main()
{

  TApplication app("app", 0, NULL);
  //gStyle->SetOptStat(0);
  auto my = new TStyle("Pub", "");
  my->cd();

  //Lettura dei dati dal file e inizializzazione variabili/oggetti
  string filename = "dati.dat";
  double mass;
  double x, y, z, vx, vy, vz;
  ifstream f(filename);

  OdeSolver ode;
  ode.fInternal = fInternal;
  ode.fExternal = fExternal;
  ode.Step(0.1);
  double time = 365;

  Vector L0; //momento angolare del sistema iniziale

  while (f >> mass >> vx >> x >> vy >> y >> vz >> z)
  {
    Vector v_n(vx, vy, vz);
    Vector x_n(x, y, z);

    MatPoint pianeta_n(mass, 0, x_n, v_n);
    ode.SetMatPoint(pianeta_n);

    L0 = L0 + pianeta_n.L();
  }

  //Creazione dei grafici (uno per pianeta)
  vector<TGraph> gr(ode.N());

  TCanvas *c = new TCanvas("Pianeti", "Pianeti", 100, 100, 1000, 1000);

  //Preparazione grafico delle coordinate dei pianeti
  double size = 5; // 5 unita' astronimiche
  c->DrawFrame(-size, -size, size, size);

  TLegend legend(0.18, 0.7, 0.3, 0.86);
  string name[11] = {"Sun", "Mercury", "Venus", "Earth", "Moon", "Mars", "Jupyter", "Saturn", "Uranus", "Neptune", "Pluto"};

  int color[11] = {kOrange + 1, kViolet + 1, kGreen + 2, kAzure + 1, kRed + 2, kRed - 7, kCyan - 8, kBlue - 7, kBlue + 1, kBlue + 2, kRed + 2};
  for (unsigned int i = 0; i < ode.N(); i++)
  {

    gr[i].SetPoint(0, ode.GetMatPoint(i).R().X(), ode.GetMatPoint(i).R().Y());
    gr[i].SetMarkerColor(color[i]);
    gr[i].SetLineColor(color[i]);
    gr[i].SetLineWidth(5);
    gr[i].SetMarkerStyle(20);
    gr[i].SetMarkerSize(0.3);
    gr[i].SetName(name[i].c_str());

    if (i == 0)
      gr[i].SetMarkerSize(1);

    legend.AddEntry(&gr[i], gr[i].GetName(), "lp");

    gr[i].Draw("P");
  }
  c->Modified();
  c->Update();
  legend.SetHeader("Il sistema solare");
  legend.Draw();

  //Run del metodo numerico + grafico in tempo reale delle coordinate e del mom. angolare totale

  TCanvas *c2 = new TCanvas("", "Momento Angolare", 1500, 800);

  c2->DrawFrame(0.1, 1 - 1e-08, time, 1 + 1e-08);

  c2->Modified();
  c2->Update();
  TLine *l = new TLine(0, 1, time, 1);
  l->Draw();

  TGraph gr2, gr3;
  //Verlet
  gr2.SetMarkerSize(0.5);
  gr2.SetMarkerStyle(20);
  gr2.SetMarkerColor(kBlue);
  //Rk2
  gr3.SetMarkerSize(0.5);
  gr3.SetMarkerStyle(20);
  gr3.SetMarkerColor(kRed);

  TLegend legend2(0.18, 0.7, 0.3, 0.86);

  legend2.AddEntry(&gr3, "Rk2", "lp");
  legend2.AddEntry(&gr2, "Verlet", "lp");
  
  c2->cd();
  legend2.Draw();
  c->cd();

  OdeSolver ode2 = ode;
  ode2.SetMethod("Rk2");

  //MOMENTO ANGOLARE : calcolo il momento angolare del sistema rispetto al sole

  int n = 1;
  while (ode.T() < time)
  {
    Vector L_t1, L_t2; //momento angolare del sistema al tempo corrente L(t) calcolato con rk2=ode2 e verlet=ode
    ode.Solve();

    ode2.Solve();

    // calcolo qua il momento angolare del sistema al tempo corrente
    for (unsigned int i = 0; i < ode.N(); i++)
    {
      L_t1 = L_t1 + ode.GetMatPoint(i).L();
      L_t2 = L_t2 + ode2.GetMatPoint(i).L();
    }

    //grafici

    if (n % 5 == 0)
    {
      for (unsigned int i = 0; i < ode.N(); i++)
      {

        c->cd();
        gr[i].SetPoint(n, ode.GetMatPoint(i).R().X(), ode.GetMatPoint(i).R().Y());
        gr[i].Draw("P");
      }
      c2->cd();

    //grafico del confronto tra i metodi
      gr2.SetPoint(n, ode.T(), L_t1.Mod() / L0.Mod()); //Verlet
      gr3.SetPoint(n, ode.T(), L_t2.Mod() / L0.Mod()); //Rk2

      gr2.Draw("P");
      gr3.Draw("P");

      c->Modified();
      c->Update();

      c2->Modified();
      c2->Update();
    }

    n++;
  }

  app.Run(true);

  return 0;
}
